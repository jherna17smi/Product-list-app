import { useState } from "react";
import ProductList from "./components/ProductList";
import "./styles.css";

export default function App() {
  // Initialize state using useState to store a list of products
  const [products] = useState([
    {
      id: 1,
      name: "Aurora Headphones",
      price: 99.99,
      description: "Wireless, lightweight, and rich sound for daily listening.",
    },
    {
      id: 2,
      name: "Nimbus Keyboard",
      price: 129.0,
      description: "Hot-swappable keys with RGB underglow and silent switches.",
    },
    {
      id: 3,
      name: "Lumen Desk Lamp",
      price: 49.5,
      description: "USB-C powered LED lamp with 3 brightness levels and tilt arm.",
    },
    {
      id: 4,
      name: "Atlas Backpack",
      price: 79.95,
      description: "Water-resistant 20L with padded laptop sleeve and quick pockets.",
    },
  ]);

  return (
    <div className="app">
      <header className="app__header">
        <h1 className="brand">Product Catalog</h1>
        <p className="subtitle">React props + state + .map() demo</p>
      </header>
      <main className="app__main">
        <ProductList products={products} />
      </main>
      <footer className="app__footer">© Jose A. Hernandez Soto</footer>
    </div>
  );
}
