import PropTypes from "prop-types";
import ProductItem from "./ProductItem";

export default function ProductList({ products = [], onAdd }) {
  if (products.length === 0) {
    return <p className="empty" role="status">No products available.</p>;
  }

  return (
    <section className="product-list" aria-label="Product list">
      {products.map((product) => (
        <ProductItem key={product.id} product={product} onAdd={onAdd} />
      ))}
    </section>
  );
}

ProductList.propTypes = {
  products: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
      name: PropTypes.string.isRequired,
      price: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
      description: PropTypes.string,
    })
  ),
  onAdd: PropTypes.func,
};
