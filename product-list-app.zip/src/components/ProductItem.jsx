import PropTypes from "prop-types";

const currency = new Intl.NumberFormat(undefined, {
  style: "currency",
  currency: "USD",
});

export default function ProductItem({ product, onAdd }) {
  const { id, name, price, description } = product ?? {};
  const n = Number(price);
  const displayPrice = Number.isFinite(n) ? currency.format(n) : "—";

  return (
    <article className="product-card" data-product-id={id}>
      <div className="product-card__body">
        <h2 className="product-card__title">{name}</h2>
        {description && <p className="product-card__desc">{description}</p>}
        <p className="product-card__price">{displayPrice}</p>
      </div>

      <button
        className="product-card__btn"
        type="button"
        aria-label={`Add ${name} to cart`}
        onClick={() => onAdd?.(product)}
      >
        Add to Cart
      </button>
    </article>
  );
}

ProductItem.propTypes = {
  product: PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
    name: PropTypes.string.isRequired,
    price: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
    description: PropTypes.string,
  }).isRequired,
  onAdd: PropTypes.func,
};
